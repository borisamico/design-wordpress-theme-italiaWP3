<!-- Inizio Fascia Appartenenza -->
<section class="preheader u-background-70">
    <div class="container">
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 entesup">
                
            <?php if ((get_option('dettagli-nome-ammin-afferente') != "") || (get_option('dettagli-logo-ammin-afferente') != "")) { ?>
                <a  aria-label="<?php echo __('Link to external site', 'italiawp3'); ?> - <?php echo esc_attr(get_option('dettagli-nome-ammin-afferente')); ?> - <?php echo __('new window', 'italiawp3'); ?>"
                    title="<?php echo esc_attr(get_option('dettagli-nome-ammin-afferente')); ?>"
                    href="<?php echo esc_url(get_option('dettagli-url-ammin-afferente')); ?>"
                    target="_blank">

                    <?php if (get_option('dettagli-logo-ammin-afferente') != "") { ?>
                        <?php if (get_option('dettagli-logo-ammin-afferente-mobile') != "" && wp_is_mobile()) : ?>
                            <img src="<?php echo esc_url(get_option('dettagli-logo-ammin-afferente-mobile')); ?>" alt="<?php echo esc_attr(get_option('dettagli-nome-ammin-afferente')); ?>" />
                        <?php else : ?>
                            <img src="<?php echo esc_url(get_option('dettagli-logo-ammin-afferente')); ?>" alt="<?php echo esc_attr(get_option('dettagli-nome-ammin-afferente')); ?>" />
                        <?php endif; ?>
                    <?php } else { ?>
                        <?php echo esc_html(get_option('dettagli-nome-ammin-afferente')); ?>
                    <?php } ?>
                </a>
            <?php } ?>

                <div class="float-right">
                    
                    <?php if (has_nav_menu('menu-alto')) { ?>
                    <div class="float-left text-right">
                    <?php
                        $menu = array(
                            'theme_location' => 'menu-alto',
                            'menu_id' => 'menu-alto',
                            'menu_class' => ''
                        );
                        wp_nav_menu($menu); ?>
                    </div>
                    <?php } ?>
                    
                    <!-- accedi -->
                    <?php if (get_option('dettagli-url-accedi') != "") { ?>
                    <div class="accedi float-left text-right">
                        <a class="btn btn-default btn-accedi" href="<?php echo esc_url(get_option('dettagli-url-accedi')); ?>">
                            <svg class="icon" aria-hidden="true" focusable="false">
                                <use xlink:href="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/ponmetroca.svg#ca-account_circle"></use>
                            </svg>
                            <span><?php echo __('Login','italiawp3'); ?></span>
                        </a>
                    </div>
                    <?php } ?>
                    <!-- accedi -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Fine Fascia Appartenenza -->

<!-- Button Menu -->
<button type="button" class="navbar-toggle menu-btn pull-left menu-left push-body jPushMenuBtn"
        aria-controls="menup" aria-expanded="false">
    <span class="sr-only"><?php echo __('Toggle navigation','italiawp3'); ?></span>
    <span class="icon-bar icon-bar1"></span>
    <span class="icon-bar icon-bar2"></span>
    <span class="icon-bar icon-bar3"></span>
</button>
<!-- Fine Button Menu -->

<!-- Inizio Menu Mobile -->
<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="menup" tabindex="-1"
     aria-label="<?php echo esc_attr__('Mobile menu','italiawp3'); ?>">
    <div class="cbp-menu-wrapper clearfix">
        <div class="logo-burger">
            <div class="logotxt-burger">
                <a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
            </div>
        </div>

        <h2 class="sr-only"><?php echo __('Main menu','italiawp3'); ?></h2>

            <?php   if(has_nav_menu('menu-principale')) {
                        $menu = array(
                            'theme_location' => 'menu-principale',
                            'menu_id' => 'site-navigation',
                            'menu_class' => 'nav navmenu',
                            'items_wrap' => '<ul id="%1$s" class="%2$s" data-element="menu">%3$s</ul>',
                        );
                        wp_nav_menu($menu);
                    }
             ?>
        
        <!-- pulsante ricerca mobile -->
        <div class="p_cercaMobile">
            <?php get_search_form(); ?>
        </div>
        <!-- pulsante ricerca mobile -->

        <?php get_template_part('template-parts/social-links', null, array(
            'ul_class'    => 'list-inline socialmobile',
            'li_class'    => '',
            'always_wrap' => true,
            'label'       => true,
        )); ?>
    </div>
</nav>
<!-- Fine Menu Mobile -->

<!-- Inizio Intestazione -->
<div class="container header">
    <div class="row clearfix header-tablet">
        <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12 col-7 comune">
            <div class="logoprint">
                <p class="logo-titolo">
                    <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $custom_logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    if (has_custom_logo()) {
                        $custom_logo = esc_url($custom_logo[0]);
                    } else {
                        $custom_logo = get_stylesheet_directory_uri() . '/images/stemma-default.png';
                    } ?>
                    <img class="custom-logo" src="<?php echo $custom_logo; ?>" alt="<?php bloginfo('name'); ?>"/>
                    <?php bloginfo('name'); ?>
                </p>
            </div>
            <div class="logoimg">
                <a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo('name'); ?>">
                    <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $custom_logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    if (has_custom_logo()) {
                        $custom_logo = esc_url($custom_logo[0]);
                    } else {
                        $custom_logo = get_stylesheet_directory_uri() . '/images/stemma-default.png';
                    } ?>
                    <img class="custom-logo" alt="<?php bloginfo('name'); ?>" src="<?php echo $custom_logo; ?>">
                </a>
            </div>
            <div class="logotxt">
                <p class="logo-titolo">
                    <a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo('name'); ?>">
                        <?php //$blog_name = get_bloginfo('name'); ?>
                        <?php
                            $blog_name = get_bloginfo('name');
                            $blog_tagline = get_bloginfo('description');
                        ?>
                        <?php if(strlen($blog_name)<=25) : ?>
                            <?php echo $blog_name; ?>
                            <?php if($blog_tagline!='') {
                                echo '<span class="tagline">'.$blog_tagline.'</span>';
                            }?>
                        <?php else : ?>
                            <small>
                                <?php echo $blog_name; ?>
                                <?php if($blog_tagline!='') {
                                    echo '<span class="tagline">'.$blog_tagline.'</span>';
                                }?>
                            </small>
                        <?php endif; ?>
                    </a>
                </p>
            </div>
        </div>

        <div class="header-social col-xl-3 col-lg-3 d-none d-lg-block d-md-none pull-right text-right">
            <!-- Inizio Social-->
            <?php get_template_part('template-parts/social-links', null, array(
                'ul_class' => 'list-inline text-right social',
            )); ?>
            <!-- Fine Social-->
        </div>

        <div class="header-cerca col-xl-2 col-lg-2 col-md-4 col-sm-5 col-5 d-none d-lg-block d-md-none text-right">
            <!-- Inizio Ricerca -->
            <?php get_search_form(); ?>
            <!-- Fine Ricerca -->
        </div>
    </div>
</div>
<!-- Fine Intestazione -->

<section class="hidden-xs" id="sub_nav">

    <div class="container">
        <div class="row">
            <div class="col-12">
            
                <nav id="main-navigation" tabindex="-1" class="navbar navbar-expand-sm has-megamenu" aria-label="<?php echo esc_attr__('Main menu','italiawp3'); ?>">
                    <div class="navbar-collapsable">
                        <?php // sr-only-focusable: era sr-only puro, quindi il bottone restava tabbabile ma invisibile. ?>
                        <div class="close-div sr-only sr-only-focusable">
                            <button class="btn close-menu" type="button">
                                <svg class="icon icon-sm icon-light" aria-hidden="true" focusable="false">
                                <use xlink:href="<?php echo esc_url( get_template_directory_uri() ); ?>/static/svg/sprite.svg#it-close"></use>
                                </svg><?php echo __('close','italiawp3'); ?>
                            </button>
                        </div>

                        <div class="menu-wrapper">
                        <?php 
                            wp_nav_menu(array(
                                'theme_location' => 'menu-principale',
                                'menu_id' => 'menu-principale',
                                'depth' => 4,
                                'container' => '',
                                'container_class' => '',
                                'menu_class' => 'nav navbar-nav',
                                'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                                'items_wrap' => '<ul id="%1$s" class="%2$s" data-element="menu">%3$s</ul>',
                                'walker' => new wp_bootstrap_navwalker()
                            ));
                         ?>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>

</section>
